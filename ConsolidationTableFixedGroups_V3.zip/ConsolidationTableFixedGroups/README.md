# Consolidation Table (Fixed Groups) - Custom Visual

نسخة بديلة من الـ Consolidation Table، بس **من غير الحاجة لعمل Unpivot** — تسحب أعمدتك زي ما هي بالظبط.

## الفكرة

فيه 6 "سلال" (Group 1 → Group 6) في الـ Data pane. كل سلة تقدر تسحب فيها **أكتر من عمود رقمي واحد** (مثلاً DB_PERFORMANCE, DB_FX, DB_ONEOFF, DB_RD_USO, ACT_VS_DB كلهم في Group 1). كل عمود بتسحبه بيظهر كعمود فرعي في الهيدر السفلي، باسمه الأصلي (أو اسم تحدده انت من Format pane)، وكل سلة بتاخدلها اسم مجموعة واحد يظهر في الهيدر العلوي (بـ colspan تلقائي حسب عدد الأعمدة اللي حطيتها فيها).

يعني لو عايز تكرر الجدول الأصلي بتاعك بالظبط:
- **Group 1** → DB_PERFORMANCE, DB_FX, DB_ONEOFF, DB_RD_USO, ACT_VS_DB (وسمّيه من Format pane: "Act vs DB")
- **Group 2** → YTD_DB_PERFORMANCE, YTD_DB_FX, YTD_DB_ONEOFF, YTD_DB_RD_USO, ACT_VS_DB_YTD (سمّيه: "YTD vs DB")
- **Group 3, 4** → لو عندك Act vs RF و YTD vs RF كمان
- **Group 5, 6** → احتياط لأي مجموعة تضيفها مستقبلًا

## خطوات البناء (نفس الأسلوب المعتاد)

1. ```
   pbiviz new ConsolidationFixedNew
   cd ConsolidationFixedNew
   npm install
   ```
2. استبدل الملفات التلاتة (`capabilities.json`, `src\visual.ts`, `style\visual.less`) بالموجودين في المجلد ده.
3. افتح `pbiviz.json` واملأ `author`, `description`, `supportUrl` (متسيبهمش فاضيين).
4. ```
   pbiviz package
   ```
5. استورد `dist\ConsolidationTableFixedGroups.1.0.0.0.pbiviz` في Power BI.

## تجربته

حمّل `ConsolidationTable_WideTestData.csv` المرفق، واسحب:
- **Category** → `DEPARTMENT`
- **Subcategory** → `COST_ELEMENT`
- **Group 1** → `DB_PERFORMANCE`, `DB_FX`, `DB_ONEOFF`, `DB_RD_USO`, `ACT_VS_DB`
- **Group 2** → `YTD_DB_PERFORMANCE`, `YTD_DB_FX`, `YTD_DB_ONEOFF`, `YTD_DB_RD_USO`, `ACT_VS_DB_YTD`

## تسمية المجموعات وصفوف الـ Total

نفس بالظبط اللي في النسخة التانية:
- Format pane → **أسماء المجموعات** → اكتب اسم كل Group (لو سيبته فاضي هيظهر "Group 1", "Group 2"... تلقائي)
- Format pane → **تسمية الأعمدة الفرعية** → إعادة تسمية أي عمود فرعي (`DB_PERFORMANCE=Perf;DB_FX=FX`...)
- Format pane → **صفوف الإجمالي** → فعّل لغاية 3 صفوف Total، كل واحد بنص وقائمة Departments خاصة بيه

## ملاحظة

لو سحبت أعمدة في Group واحد بس، هتلاقي الهيدر العلوي خلية واحدة ممدودة (colspan) فوق كل الأعمدة دي. لو عايز عمود "مستقل" من غير أي مجموعة ظاهرة فوقه، سيب اسم المجموعة فاضي في Format pane وهيظهر "Group N" الافتراضي - أو غيّره لأي اسم بسيط تحبه.

## أسماء ديناميكية جاية من الداتا (زي اسم الشهر الحالي)

لو عايز اسم عمود أو مجموعة يتغير تلقائي حسب قيمة موجودة في عمود تاني في الداتا بتاعتك (زي `CurMonth`)، بدل ما تكتب اسم ثابت:

1. اسحب العمود ده (`CurMonth` مثلًا) في بكت **"Dynamic Labels"** الجديد في الـ Data pane.
2. في `Rename columns` أو `أسماء المجموعات`، بدل ما تكتب اسم ثابت، اكتب `$` وبعدها اسم العمود بالظبط زي ما ظاهر في الـ Data pane:
   ```
   Sum of ACTUALS=$CurMonth
   ```
3. أي وقت الداتا تتغير (شهر جديد مثلاً)، الاسم هيتغير لوحده من غير ما تلمس Format pane تاني.

نفس الميزة شغالة كمان مع نصوص خلية الـ Description (Line 1 / Line 2) — تقدر تكتب فيهم `$CurMonth` بدل النص الثابت.

## تحديث: منطق صفوف الـ Total (Exclude بدل Include)

من دلوقتي، أي صف Total مفعّل بيجمع **كل الصفوف تلقائيًا افتراضيًا**. لو عايز تستثني صف أو أكتر (زي استبعاد Regulatory)، اكتب أسماءهم في حقل **"rows to EXCLUDE"** بدل ما تكتب كل الأسماء اللي عايزها تدخل.

مثال:
- سيب الحقل فاضي → المجموع = كل الصفوف
- اكتب `Regulatory` → المجموع = كل الصفوف ما عدا Regulatory
