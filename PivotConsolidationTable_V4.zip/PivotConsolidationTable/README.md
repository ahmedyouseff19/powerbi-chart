# Pivot Consolidation Table - Custom Visual

نسخة تالتة، الفرق الجوهري عن اللي فاتوا: الأعمدة الفرعية (زي Below, Dep, Opex) مش أعمدة منفصلة في بياناتك ولا محتاجة Unpivot يدوي بصيغة `|` — دي **قيم موجودة في عمود واحد** (زي `P&L Category`)، والـ Visual بيلف عليها ديناميكيًا لوحده (Pivot تلقائي).

## الفكرة

- **Row** → عمود الصف الأساسي (زي `ROW_NAME`: INCA, VSOL, SAMS...)
- **Row sub-level (optional)** → لو عايز صفوف فرعية قابلة للطي تحت كل صف
- **Column values** → العمود اللي قيمه هتتحول لأعمدة فرعية تلقائيًا (زي `PNL_CATEGORY`: Below, Dep, Opex...) — أي قيمة جديدة تتضاف هنا تظهر عمود جديد لوحدها من غير أي تعديل
- **Group 1 - Measure** إلى **Group 6 - Measure** → كل سلة تاخد **قياس واحد بس** (زي `ACTUALS`, `ACT_VS_DB`, `ACT_VS_DB_YTD`) وبيمثل مجموعة كاملة فوق (Actuals, Act vs DB, YTD vs DB)

## عمود Total التلقائي

لكل مجموعة (Group)، الـ Visual بيضيف عمود "Total" في آخرها تلقائيًا = مجموع كل الأعمدة الفرعية (Below+Dep+Opex) لنفس المجموعة، من غير ما يكون موجود في الداتا أصلاً. تقدر تقفل الميزة دي أو تغيّر اسم العمود من Format pane.

## خطوات البناء (نفس الأسلوب المعتاد)

```
pbiviz new PivotConsolidationNew
cd PivotConsolidationNew
npm install
```
استبدل `capabilities.json`, `src\visual.ts`, `style\visual.less`، اعمل `pbiviz.json` مليان (author/description/supportUrl)، وبعدين:
```
pbiviz package
```

## تجربته

حمّل `PivotConsolidationTable_TestData.csv` واسحب:
- **Row** → `ROW_NAME`
- **Column values** → `PNL_CATEGORY`
- **Group 1 - Measure** → `ACTUALS`
- **Group 2 - Measure** → `ACT_VS_DB`
- **Group 3 - Measure** → `ACT_VS_DB_YTD`

## صفوف الـ Total الأخيرة

لغاية 3 صفوف قابلة للتخصيص (زي الـ Visual التاني بالظبط)، من Format pane → **Total rows**:
- فعّل الصف
- اكتب Label (زي "Total")
- اكتب أسماء الصفوف اللي تدخل فيه (زي `INCA, VSOL, SAMS, VPC, Branding`) — أو كلهم لو عايز إجمالي شامل

## باقي الخصائص

نفس بالظبط اللي في الـ Visual التاني: ألوان، حجم خط، عرض الفاصل بين المجموعات، إظهار/إخفاء أيقونة +/-، Bold للصفوف الرئيسية، Bold منفصل لأرقام الصفوف الفرعية، خلية Description بسطر أو سطرين مع فاصل قابل للتحكم، وإعادة تسمية أي قيمة عمود من Format pane.

## تحديث: منطق صفوف الـ Total (Exclude بدل Include)

أي صف Total مفعّل بيجمع **كل الصفوف تلقائيًا افتراضيًا**. لو عايز تستثني صف أو أكتر، اكتب أسماءهم في حقل **"rows to EXCLUDE"** بدل ما تكتب كل الأسماء اللي عايزها تدخل.

مثال:
- سيب الحقل فاضي → المجموع = كل الصفوف
- اكتب `Regulatory` → المجموع = كل الصفوف ما عدا Regulatory
