"use strict";

import "../style/visual.less";
import powerbi from "powerbi-visuals-api";

import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import DataView = powerbi.DataView;
import DataViewValueColumnGroup = powerbi.DataViewValueColumnGroup;
import DataViewValueColumn = powerbi.DataViewValueColumn;

const BUCKET_ROLES = ["bucket1", "bucket2", "bucket3", "bucket4", "bucket5", "bucket6"];
const TOTAL_KEY = "__TOTAL__"; // مفتاح داخلي يمثل عمود الـ Total التلقائي (مش قيمة حقيقية من الداتا)

interface ITotalRowConfig {
    enabled: boolean;
    label: string;
    exclude: string[]; // أسماء الصفوف المستبعدة (فاضي = يجمع كل الصفوف)
}

interface ISettings {
    negativeColor: string;
    headerColor: string;
    totalRowColor: string;
    fontSize: number;
    defaultExpanded: boolean;
    groupGapWidth: number;
    showToggleIcon: boolean;
    boldMainRows: boolean;
    boldChildNumbers: boolean;
    showTotalSubColumn: boolean;
    totalSubColumnLabel: string;
    bucketLabels: string[];
    relabelMap: Record<string, string>;
    totalRows: ITotalRowConfig[];
    descTwoLines: boolean;
    descLine1: string;
    descLine2: string;
    descSeparatorSize: number;
}

function getDefaultSettings(): ISettings {
    return {
        negativeColor: "#E20000",
        headerColor: "#E20000",
        totalRowColor: "#F0F0F0",
        fontSize: 13,
        defaultExpanded: true,
        groupGapWidth: 8,
        showToggleIcon: true,
        boldMainRows: true,
        boldChildNumbers: false,
        showTotalSubColumn: true,
        totalSubColumnLabel: "Total",
        bucketLabels: ["", "", "", "", "", ""],
        relabelMap: {},
        totalRows: [
            { enabled: false, label: "Total", exclude: [] },
            { enabled: false, label: "Total", exclude: [] },
            { enabled: false, label: "Total", exclude: [] }
        ],
        descTwoLines: false,
        descLine1: "Description",
        descLine2: "",
        descSeparatorSize: 1
    };
}

function parseRelabelMap(text: string): Record<string, string> {
    const map: Record<string, string> = {};
    if (!text) return map;
    text.split(";").forEach(pair => {
        const idx = pair.indexOf("=");
        if (idx === -1) return;
        const key = pair.substring(0, idx).trim();
        const val = pair.substring(idx + 1).trim();
        if (key) map[key] = val;
    });
    return map;
}

function parseRowList(text: string): string[] {
    if (!text) return [];
    return text.split(",").map(s => s.trim().toLowerCase()).filter(s => s.length > 0);
}

function relabel(map: Record<string, string>, key: string): string {
    return map[key] !== undefined ? map[key] : key;
}

function formatNumber(value: number, decimals: number = 0): string {
    if (value === null || value === undefined || isNaN(value)) return "";
    const abs = Math.abs(value).toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
    return value < 0 ? `(${abs})` : abs;
}

// وصف عمود معروض واحد: إما عمود فئة حقيقي (Below/Dep/Opex) أو عمود الـ Total التلقائي
interface IDisplayColumn {
    bucketIndex: number;
    categoryKey: string; // TOTAL_KEY للعمود التلقائي
    label: string;
    isGroupStart: boolean;
    isTotalColumn: boolean;
}

export class Visual implements IVisual {
    private target: HTMLElement;
    private settings: ISettings;
    private expandedState: { [key: string]: boolean } = {};

    constructor(options: VisualConstructorOptions) {
        this.target = options.element;
        this.target.classList.add("pc-visual-root");
    }

    public update(options: VisualUpdateOptions) {
        this.target.innerHTML = "";

        const dataView = options.dataViews && options.dataViews[0];
        if (!dataView || !dataView.categorical || !dataView.categorical.categories || !dataView.categorical.categories.length || !dataView.categorical.values) {
            this.target.innerHTML = `<div class="pc-empty">Add a Row field, a Column values field, and at least one field in any Group (1 to 6)</div>`;
            return;
        }

        this.settings = this.parseSettings(dataView);
        this.applyThemeVars();

        const categorical = dataView.categorical;
        const rowColumn = categorical.categories[0];
        const rowSubColumn = categorical.categories.length > 1 ? categorical.categories[1] : null;

        const rowValues: string[] = rowColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString());
        const rowSubValues: string[] | null = rowSubColumn ? rowSubColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString()) : null;

        const groups: DataViewValueColumnGroup[] = categorical.values.grouped ? categorical.values.grouped() : [];

        // ترتيب القيم (Below, Dep, Opex...) بنفس ترتيب ظهورها الأول في الداتا
        const categoryOrder: string[] = groups.map(g => (g.name !== null && g.name !== undefined) ? g.name.toString() : "");

        // نحدد أنهي سلال (buckets) فعليًا فيها بيانات
        const usedBuckets: number[] = [];
        BUCKET_ROLES.forEach((role, idx) => {
            const hasData = groups.some(g => g.values.some(c => c.source.roles && c.source.roles[role]));
            if (hasData) usedBuckets.push(idx);
        });

        // بناء قائمة الأعمدة المعروضة: لكل سلة مستخدمة -> كل الفئات بالترتيب -> عمود Total تلقائي (لو مفعّل)
        const displayColumns: IDisplayColumn[] = [];
        usedBuckets.forEach(bucketIdx => {
            categoryOrder.forEach((catName, catIdx) => {
                displayColumns.push({
                    bucketIndex: bucketIdx,
                    categoryKey: catName,
                    label: relabel(this.settings.relabelMap, catName),
                    isGroupStart: catIdx === 0,
                    isTotalColumn: false
                });
            });
            if (this.settings.showTotalSubColumn) {
                displayColumns.push({
                    bucketIndex: bucketIdx,
                    categoryKey: TOTAL_KEY,
                    label: this.settings.totalSubColumnLabel,
                    isGroupStart: categoryOrder.length === 0,
                    isTotalColumn: true
                });
            }
        });

        const table = document.createElement("table");
        table.className = "pc-table";
        table.style.fontSize = `${this.settings.fontSize}px`;
        table.appendChild(this.buildTwoLevelHeader(displayColumns));

        const tbody = document.createElement("tbody");
        const rowCount = rowValues.length;
        const allIndices = Array.from({ length: rowCount }, (_, i) => i);

        const rowOrder: string[] = [];
        rowValues.forEach(r => { if (rowOrder.indexOf(r) === -1) rowOrder.push(r); });

        rowOrder.forEach(rowName => {
            if (this.expandedState[rowName] === undefined) {
                this.expandedState[rowName] = this.settings.defaultExpanded;
            }
            const rIndices = allIndices.filter(i => rowValues[i] === rowName);
            const hasChildren = !!rowSubValues;

            const parentValues = displayColumns.map(dc => this.computeCell(groups, dc, rIndices));
            tbody.appendChild(this.buildDataRow(rowName, parentValues, displayColumns, true, hasChildren, rowName));

            if (hasChildren) {
                const subOrder: string[] = [];
                rIndices.forEach(i => { const s = rowSubValues![i]; if (subOrder.indexOf(s) === -1) subOrder.push(s); });

                subOrder.forEach(subName => {
                    const subIndices = rIndices.filter(i => rowSubValues![i] === subName);
                    const subValues = displayColumns.map(dc => this.computeCell(groups, dc, subIndices));
                    const row = this.buildDataRow(subName, subValues, displayColumns, false, false, rowName);
                    row.dataset.parent = rowName;
                    row.style.display = this.expandedState[rowName] ? "" : "none";
                    tbody.appendChild(row);
                });
            }
        });

        this.settings.totalRows.forEach(tr => {
            if (!tr.enabled) return;
            // الافتراضي: يجمع كل الصفوف. أي اسم مكتوب في exclude بيتشال من المجموع
            const matchedIndices = allIndices.filter(i => tr.exclude.indexOf(rowValues[i].trim().toLowerCase()) === -1);
            const totals = displayColumns.map(dc => this.computeCell(groups, dc, matchedIndices));
            tbody.appendChild(this.buildTotalRow(tr.label, totals, displayColumns));
        });

        table.appendChild(tbody);
        this.target.appendChild(table);
    }

    // بيحسب قيمة خلية واحدة: إما مجموع فئة معينة، أو Total (مجموع كل الفئات) لنفس السلة، على مجموعة من صفوف الداتا
    private computeCell(groups: DataViewValueColumnGroup[], dc: IDisplayColumn, indices: number[]): number {
        if (dc.isTotalColumn) {
            let sum = 0;
            groups.forEach(g => {
                const col = this.findBucketColumn(g, dc.bucketIndex);
                if (col) sum += this.sumIndices(col, indices);
            });
            return sum;
        }
        const group = groups.find(g => ((g.name !== null && g.name !== undefined) ? g.name.toString() : "") === dc.categoryKey);
        if (!group) return 0;
        const col = this.findBucketColumn(group, dc.bucketIndex);
        if (!col) return 0;
        return this.sumIndices(col, indices);
    }

    private findBucketColumn(group: DataViewValueColumnGroup, bucketIndex: number): DataViewValueColumn | undefined {
        const role = BUCKET_ROLES[bucketIndex];
        return group.values.find(c => c.source.roles && c.source.roles[role]);
    }

    private sumIndices(col: DataViewValueColumn, indices: number[]): number {
        let sum = 0;
        indices.forEach(i => {
            const v = col.values[i] as number;
            if (v !== null && v !== undefined && !isNaN(v)) sum += v;
        });
        return sum;
    }

    private buildDescriptionCell(): HTMLTableCellElement {
        const descTh = document.createElement("td");
        descTh.rowSpan = 2;
        descTh.className = "pc-desc-header";
        if (this.settings.descTwoLines) {
            descTh.appendChild(document.createTextNode(this.settings.descLine1));
            const sep = document.createElement("div");
            sep.className = "pc-desc-separator";
            sep.style.borderTopWidth = `${this.settings.descSeparatorSize}px`;
            descTh.appendChild(sep);
            descTh.appendChild(document.createTextNode(this.settings.descLine2));
        } else {
            descTh.textContent = this.settings.descLine1;
        }
        return descTh;
    }

    private buildTwoLevelHeader(columns: IDisplayColumn[]): HTMLTableSectionElement {
        const thead = document.createElement("thead");

        const topRow = document.createElement("tr");
        topRow.appendChild(this.buildDescriptionCell());

        let i = 0;
        while (i < columns.length) {
            const bIdx = columns[i].bucketIndex;
            let span = 1;
            while (i + span < columns.length && columns[i + span].bucketIndex === bIdx) span++;
            const th = document.createElement("td");
            th.colSpan = span;
            if (i > 0) th.classList.add("pc-group-gap");
            const label = this.settings.bucketLabels[bIdx];
            th.textContent = label && label.length > 0 ? label : `Group ${bIdx + 1}`;
            topRow.appendChild(th);
            i += span;
        }
        thead.appendChild(topRow);

        const subRow = document.createElement("tr");
        columns.forEach((c, idx) => {
            const th = document.createElement("td");
            if (c.isGroupStart && idx > 0) th.classList.add("pc-group-gap");
            if (c.isTotalColumn) th.classList.add("pc-total-col");
            th.textContent = c.label;
            subRow.appendChild(th);
        });
        thead.appendChild(subRow);

        return thead;
    }

    private appendToggleAndLabel(cell: HTMLTableCellElement, label: string, clickable: boolean, parentKey: string) {
        if (clickable) {
            if (this.settings.showToggleIcon) {
                const icon = document.createElement("span");
                icon.className = "pc-toggle-icon";
                icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
                cell.appendChild(icon);
                (cell as any)._toggleIcon = icon;
            }
            cell.style.cursor = "pointer";
            cell.addEventListener("click", () => {
                this.expandedState[parentKey] = !this.expandedState[parentKey];
                const rows = this.target.querySelectorAll(`tr[data-parent="${CSS.escape(parentKey)}"]`);
                rows.forEach((r: HTMLElement) => { r.style.display = this.expandedState[parentKey] ? "" : "none"; });
                const icon = (cell as any)._toggleIcon as HTMLElement;
                if (icon) icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
            });
        }
        cell.appendChild(document.createTextNode(label));
    }

    private buildDataRow(label: string, values: number[], columns: IDisplayColumn[], isParent: boolean, clickable: boolean, parentKey: string): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = isParent ? "pc-main-row" : "pc-sub-row";

        const labelCell = document.createElement("td");
        labelCell.className = isParent ? "pc-main-title" : "pc-sub-title";
        if (isParent) {
            this.appendToggleAndLabel(labelCell, label, clickable, parentKey);
            labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        } else {
            labelCell.textContent = label;
        }
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "pc-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("pc-group-gap");
            if (columns[idx].isTotalColumn) cell.classList.add("pc-total-col");
            if (v < 0) cell.style.color = this.settings.negativeColor;
            if (isParent) {
                cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            } else {
                cell.style.fontWeight = this.settings.boldChildNumbers ? "bold" : "normal";
            }
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private buildTotalRow(label: string, values: number[], columns: IDisplayColumn[]): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = "pc-grand-total-row";

        const labelCell = document.createElement("td");
        labelCell.className = "pc-grand-total-title";
        labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        labelCell.textContent = label;
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "pc-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("pc-group-gap");
            if (columns[idx].isTotalColumn) cell.classList.add("pc-total-col");
            if (v < 0) cell.style.color = this.settings.negativeColor;
            cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private applyThemeVars() {
        this.target.style.setProperty("--pc-header-color", this.settings.headerColor);
        this.target.style.setProperty("--pc-total-row-color", this.settings.totalRowColor);
        this.target.style.setProperty("--pc-gap-width", `${this.settings.groupGapWidth}px`);
    }

    private parseSettings(dataView: DataView): ISettings {
        const settings = getDefaultSettings();
        const objects = dataView && dataView.metadata && dataView.metadata.objects;
        if (!objects) return settings;

        const dp: any = objects["dataPoint"];
        const tf: any = objects["tableFormat"];
        const bl: any = objects["bucketLabels"];
        const cl: any = objects["columnLabels"];
        const tr: any = objects["totalRows"];
        const dh: any = objects["descriptionHeader"];

        if (dp) {
            if (dp.negativeColor && dp.negativeColor.solid) settings.negativeColor = dp.negativeColor.solid.color;
            if (dp.headerColor && dp.headerColor.solid) settings.headerColor = dp.headerColor.solid.color;
            if (dp.totalRowColor && dp.totalRowColor.solid) settings.totalRowColor = dp.totalRowColor.solid.color;
        }
        if (tf) {
            if (typeof tf.fontSize === "number") settings.fontSize = tf.fontSize;
            if (typeof tf.defaultExpanded === "boolean") settings.defaultExpanded = tf.defaultExpanded;
            if (typeof tf.groupGapWidth === "number") settings.groupGapWidth = tf.groupGapWidth;
            if (typeof tf.showToggleIcon === "boolean") settings.showToggleIcon = tf.showToggleIcon;
            if (typeof tf.boldMainRows === "boolean") settings.boldMainRows = tf.boldMainRows;
            if (typeof tf.boldChildNumbers === "boolean") settings.boldChildNumbers = tf.boldChildNumbers;
            if (typeof tf.showTotalSubColumn === "boolean") settings.showTotalSubColumn = tf.showTotalSubColumn;
            if (typeof tf.totalSubColumnLabel === "string" && tf.totalSubColumnLabel) settings.totalSubColumnLabel = tf.totalSubColumnLabel;
        }
        if (bl) {
            settings.bucketLabels = [1, 2, 3, 4, 5, 6].map(n => (typeof bl[`bucket${n}Label`] === "string" ? bl[`bucket${n}Label`] : ""));
        }
        if (cl && typeof cl.relabelMap === "string") {
            settings.relabelMap = parseRelabelMap(cl.relabelMap);
        }
        if (tr) {
            settings.totalRows = [1, 2, 3].map(n => ({
                enabled: typeof tr[`enableRow${n}`] === "boolean" ? tr[`enableRow${n}`] : false,
                label: typeof tr[`label${n}`] === "string" && tr[`label${n}`] ? tr[`label${n}`] : "Total",
                exclude: typeof tr[`excludeRows${n}`] === "string" ? parseRowList(tr[`excludeRows${n}`]) : []
            }));
        }
        if (dh) {
            if (typeof dh.twoLines === "boolean") settings.descTwoLines = dh.twoLines;
            if (typeof dh.line1Text === "string" && dh.line1Text) settings.descLine1 = dh.line1Text;
            if (typeof dh.line2Text === "string") settings.descLine2 = dh.line2Text;
            if (typeof dh.separatorSize === "number") settings.descSeparatorSize = dh.separatorSize;
        }
        return settings;
    }

    public enumerateObjectInstances(options: powerbi.EnumerateVisualObjectInstancesOptions): powerbi.VisualObjectInstanceEnumeration {
        const objectName = options.objectName;
        const settings = this.settings || getDefaultSettings();
        const instances: powerbi.VisualObjectInstance[] = [];

        if (objectName === "dataPoint") {
            instances.push({
                objectName,
                properties: {
                    negativeColor: { solid: { color: settings.negativeColor } },
                    headerColor: { solid: { color: settings.headerColor } },
                    totalRowColor: { solid: { color: settings.totalRowColor } }
                },
                selector: null
            });
        }
        if (objectName === "tableFormat") {
            instances.push({
                objectName,
                properties: {
                    fontSize: settings.fontSize,
                    defaultExpanded: settings.defaultExpanded,
                    groupGapWidth: settings.groupGapWidth,
                    showToggleIcon: settings.showToggleIcon,
                    boldMainRows: settings.boldMainRows,
                    boldChildNumbers: settings.boldChildNumbers,
                    showTotalSubColumn: settings.showTotalSubColumn,
                    totalSubColumnLabel: settings.totalSubColumnLabel
                },
                selector: null
            });
        }
        if (objectName === "bucketLabels") {
            const props: any = {};
            settings.bucketLabels.forEach((label, idx) => { props[`bucket${idx + 1}Label`] = label; });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "columnLabels") {
            const mapText = Object.keys(settings.relabelMap).map(k => `${k}=${settings.relabelMap[k]}`).join(";");
            instances.push({ objectName, properties: { relabelMap: mapText }, selector: null });
        }
        if (objectName === "totalRows") {
            const props: any = {};
            settings.totalRows.forEach((tr, idx) => {
                const n = idx + 1;
                props[`enableRow${n}`] = tr.enabled;
                props[`label${n}`] = tr.label;
                props[`excludeRows${n}`] = tr.exclude.join(", ");
            });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "descriptionHeader") {
            instances.push({
                objectName,
                properties: {
                    twoLines: settings.descTwoLines,
                    line1Text: settings.descLine1,
                    line2Text: settings.descLine2,
                    separatorSize: settings.descSeparatorSize
                },
                selector: null
            });
        }
        return instances;
    }
}
