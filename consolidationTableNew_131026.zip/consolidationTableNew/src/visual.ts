"use strict";

import "../style/visual.less";
import powerbi from "powerbi-visuals-api";

import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import DataView = powerbi.DataView;
import DataViewValueColumn = powerbi.DataViewValueColumn;
import DataViewCategoryColumn = powerbi.DataViewCategoryColumn;

const GROUP_ROLES = ["group1", "group2", "group3", "group4", "group5", "group6"];
const DYNAMIC_LABEL_ROLE = "dynamicLabels";

interface ITotalRowConfig {
    enabled: boolean;
    label: string;
}

interface ISettings {
    negativeColor: string;
    headerColor: string;
    groupHeaderColor: string;
    totalRowColor: string;
    fontSize: number;
    defaultExpanded: boolean;
    groupGapWidth: number; // px - عرض الفاصل الأبيض بين كل مجموعة والتانية
    showToggleIcon: boolean;
    boldMainRows: boolean;
    boldChildNumbers: boolean; // Bold لأرقام صفوف Cost Element بس، من غير ما يأثر على اسم الـ Cost Element
    groupLabels: string[];

    totalRows: ITotalRowConfig[];
    descTwoLines: boolean; // خلية الـ Description تبقى سطر واحد أو سطرين جوه نفس الخلية
    descLine1: string;
    descLine2: string;
    descSeparatorSize: number; // px - سمك الفاصل بين السطرين
}

function getDefaultSettings(): ISettings {
    return {
        negativeColor: "#E20000",
        headerColor: "#E20000",
        groupHeaderColor: "#7F7F7F",
        totalRowColor: "#F0F0F0",
        fontSize: 13,
        defaultExpanded: true,
        groupGapWidth: 8,
        showToggleIcon: true,
        boldMainRows: true,
        boldChildNumbers: false,
        groupLabels: ["", "", "", "", "", ""],

        totalRows: [
            { enabled: false, label: "Total" },
            { enabled: false, label: "Total" },
            { enabled: false, label: "Total" }
        ],
        descTwoLines: false,
        descLine1: "Description",
        descLine2: "",
        descSeparatorSize: 1
    };
}

// لو النص بيبدأ بـ $ يبقى ده اسم عمود ديناميكي (من Dynamic Labels)، نجيب قيمته الفعلية من dynamicMap
// لو مش موجود قيمة أو النص مش بيبدأ بـ $، نرجع النص الأصلي زي ما هو
function resolveLabel(text: string, dynamicMap: Record<string, string>): string {
    if (text && text.charAt(0) === "$") {
        const key = text.substring(1).trim();
        return dynamicMap[key] !== undefined ? dynamicMap[key] : text;
    }
    return text;
}

function formatNumber(value: number, decimals: number = 0): string {
    if (value === null || value === undefined || isNaN(value)) return "";
    const abs = Math.abs(value).toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
    return value < 0 ? `(${abs})` : abs;
}

interface IColumnInfo {
    column: DataViewValueColumn;
    groupIndex: number;
    subLabel: string;
    isGroupStart: boolean; // أول عمود في مجموعة جديدة - بياخد الفاصل الأبيض على شماله
}

export class Visual implements IVisual {
    private target: HTMLElement;
    private settings: ISettings;
    private expandedState: { [key: string]: boolean } = {};
    private dynamicLabelValues: Record<string, string> = {};
    private host: IVisualHost;
    // كل Cost Element فريد (اسمه + أول عمود/صف لقيناه فيه)، بنعيد بناءها كل update() وبنستخدمها لبناء الـ Color pickers
    private ceCategoryEntries: { label: string; column: DataViewCategoryColumn; index: number }[] = [];
    // كل Department فريد - بنستخدمها لبناء مفاتيح "ادخل في Total N؟" تلقائيًا
    private deptCategoryEntries: { label: string; column: DataViewCategoryColumn; index: number }[] = [];
    // كل عمود (Measure) جاي من سلة Group - بنستخدمها لبناء صندوق "اسم جديد" تلقائي لكل عمود
    private columnEntries: { label: string; column: DataViewValueColumn }[] = [];

    constructor(options: VisualConstructorOptions) {
        this.target = options.element;
        this.host = options.host;
        this.target.classList.add("ct-visual-root");
    }

    public update(options: VisualUpdateOptions) {
        this.target.innerHTML = "";

        const dataView = options.dataViews && options.dataViews[0];
        if (!dataView || !dataView.categorical || !dataView.categorical.categories || !dataView.categorical.categories.length || !dataView.categorical.values || !dataView.categorical.values.length) {
            this.target.innerHTML = `<div class="ct-empty">Add Department to Category, and at least one field to any Group (1 to 6)</div>`;
            return;
        }

        this.settings = this.parseSettings(dataView);
        this.applyThemeVars();

        const categorical = dataView.categorical;
        const deptColumn = categorical.categories[0];
        const ceColumn = categorical.categories.length > 1 ? categorical.categories[1] : null;

        const deptValues: string[] = deptColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString());
        const ceValues: string[] | null = ceColumn ? ceColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString()) : null;

        const rawColumns: { column: DataViewValueColumn; groupIndex: number; subLabel: string }[] = [];
        this.dynamicLabelValues = {};
        this.columnEntries = [];

        categorical.values.forEach((col: DataViewValueColumn) => {
            const roles = col.source.roles || {};

            // لو العمود ده جاي من بكت Dynamic Labels، ناخد أول قيمة موجودة فيه (مش هيتحط كعمود بيانات في الجدول)
            if (roles[DYNAMIC_LABEL_ROLE]) {
                const firstVal = col.values.find(v => v !== null && v !== undefined);
                this.dynamicLabelValues[col.source.displayName] = firstVal !== undefined ? firstVal.toString() : "";
                return;
            }

            let groupIndex = -1;
            for (let g = 0; g < GROUP_ROLES.length; g++) {
                if (roles[GROUP_ROLES[g]]) { groupIndex = g; break; }
            }
            if (groupIndex === -1) return;
            this.columnEntries.push({ label: col.source.displayName, column: col });
            rawColumns.push({ column: col, groupIndex, subLabel: "" });
        });

        // الاسم النهائي: لو المستخدم كتب اسم جديد للعمود ده من الـ Format pane، استخدمه؛ غير كده الاسم الأصلي.
        // وبعدين نحل أي $اسم ديناميكي فيه
        rawColumns.forEach(c => {
            const customText = this.getColumnText(c.column);
            const baseLabel = customText || c.column.source.displayName;
            c.subLabel = resolveLabel(baseLabel, this.dynamicLabelValues);
        });

        const columns: IColumnInfo[] = rawColumns.map((c, idx) => ({
            ...c,
            isGroupStart: idx === 0 || rawColumns[idx - 1].groupIndex !== c.groupIndex
        }));

        const table = document.createElement("table");
        table.className = "ct-table";
        table.style.fontSize = `${this.settings.fontSize}px`;

        table.appendChild(this.buildTwoLevelHeader(columns));

        const tbody = document.createElement("tbody");
        const rowCount = deptValues.length;
        const allIndices = Array.from({ length: rowCount }, (_, i) => i);

        const deptOrder: string[] = [];
        deptValues.forEach(d => { if (deptOrder.indexOf(d) === -1) deptOrder.push(d); });

        // قايمة كل Department فريد - هتستخدم لبناء مفاتيح "ادخل في Total N؟" تلقائيًا في الـ Format pane
        this.deptCategoryEntries = deptOrder.map(label => ({
            label,
            column: deptColumn,
            index: deptValues.indexOf(label)
        }));

        // قايمة كل Cost Element فريد (باسمه) مع أول صف لقيناه فيه - دي اللي هتظهر كـ Color picker منفصل
        // في الـ Format pane، زي "Data colors" بالظبط
        this.ceCategoryEntries = [];
        if (ceColumn) {
            const seenCE = new Set<string>();
            ceValues!.forEach((v, i) => {
                if (!seenCE.has(v)) {
                    seenCE.add(v);
                    this.ceCategoryEntries.push({ label: v, column: ceColumn, index: i });
                }
            });
        }

        deptOrder.forEach(dept => {
            if (this.expandedState[dept] === undefined) {
                this.expandedState[dept] = this.settings.defaultExpanded;
            }
            const deptIndices = allIndices.filter(i => deptValues[i] === dept);
            const hasChildren = !!ceValues;

            const deptTotals = columns.map(c => this.sumIndices(c.column, deptIndices));
            tbody.appendChild(this.buildDataRow(dept, deptTotals, columns, true, hasChildren, dept));

            if (hasChildren) {
                const ceOrder: string[] = [];
                deptIndices.forEach(i => { const c = ceValues![i]; if (ceOrder.indexOf(c) === -1) ceOrder.push(c); });

                ceOrder.forEach(ce => {
                    const ceIndices = deptIndices.filter(i => ceValues![i] === ce);
                    const ceTotals = columns.map(c => this.sumIndices(c.column, ceIndices));
                    // نجيب اللون المحفوظ فعليًا لـ Cost Element ده (لو المستخدم اختاره من الـ Format pane)
                    const rowBgColor = this.getCategoryFillColor(ceColumn!, ceIndices[0]);
                    const row = this.buildDataRow(ce, ceTotals, columns, false, false, dept, rowBgColor);
                    row.dataset.parent = dept;
                    row.style.display = this.expandedState[dept] ? "" : "none";
                    tbody.appendChild(row);
                });
            }
        });

        this.settings.totalRows.forEach((tr, idx) => {
            if (!tr.enabled) return;
            const n = idx + 1;
            // الافتراضي: كل Department مشمول، إلا لو قفلته بنفسك من مفتاح "ادخل في Total N؟"
            const matchedIndices = allIndices.filter(i => this.getInclusionFlag(deptColumn, i, n));
            const totals = columns.map(c => this.sumIndices(c.column, matchedIndices));
            tbody.appendChild(this.buildTotalRow(tr.label, totals, columns));
        });

        table.appendChild(tbody);
        this.target.appendChild(table);
    }

    // بيقرأ الاسم الجديد اللي المستخدم كتبه لعمود معين (Measure) من الـ Format pane، لو موجود
    private getColumnText(column: DataViewValueColumn): string | undefined {
        const objs: any = column.objects;
        if (objs && objs["columnLabels"] && typeof objs["columnLabels"].newName === "string" && objs["columnLabels"].newName) {
            return objs["columnLabels"].newName;
        }
        return undefined;
    }

    // بيقرأ هل الصف ده (Department) مشمول في صف Total رقم n - الافتراضي true لو المستخدم معملش حاجة
    private getInclusionFlag(column: DataViewCategoryColumn, rowIndex: number, n: number): boolean {
        const objs: any = column.objects && column.objects[rowIndex];
        if (objs && objs["totalRowInclusion"] && typeof objs["totalRowInclusion"][`include${n}`] === "boolean") {
            return objs["totalRowInclusion"][`include${n}`];
        }
        return true;
    }

    // بيقرأ اللون اللي Power BI حفظه لصف معين (لو المستخدم اختاره من الـ Color picker في الـ Format pane)
    private getCategoryFillColor(column: DataViewCategoryColumn, rowIndex: number): string | undefined {
        const objs: any = column.objects && column.objects[rowIndex];
        if (objs && objs["rowColors"] && objs["rowColors"].fill && objs["rowColors"].fill.solid) {
            return objs["rowColors"].fill.solid.color;
        }
        return undefined;
    }

    private sumIndices(col: DataViewValueColumn, indices: number[]): number {
        let sum = 0;
        indices.forEach(i => {
            const v = col.values[i] as number;
            if (v !== null && v !== undefined && !isNaN(v)) sum += v;
        });
        return sum;
    }

    // خلية الـ Description (الأعلى-يسار): سطر واحد أو سطرين جوه نفس الخلية حسب الإعداد
    private buildDescriptionCell(): HTMLTableCellElement {
        const descTh = document.createElement("td");
        descTh.rowSpan = 2;
        descTh.className = "ct-desc-header";
        if (this.settings.descTwoLines) {
            descTh.appendChild(document.createTextNode(resolveLabel(this.settings.descLine1, this.dynamicLabelValues)));
            const sep = document.createElement("div");
            sep.className = "ct-desc-separator";
            sep.style.borderTopWidth = `${this.settings.descSeparatorSize}px`;
            descTh.appendChild(sep);
            descTh.appendChild(document.createTextNode(resolveLabel(this.settings.descLine2, this.dynamicLabelValues)));
        } else {
            descTh.textContent = resolveLabel(this.settings.descLine1, this.dynamicLabelValues);
        }
        return descTh;
    }

    private buildTwoLevelHeader(columns: IColumnInfo[]): HTMLTableSectionElement {
        const thead = document.createElement("thead");

        const topRow = document.createElement("tr");
        topRow.appendChild(this.buildDescriptionCell());

        let i = 0;
        while (i < columns.length) {
            const gIdx = columns[i].groupIndex;
            let span = 1;
            while (i + span < columns.length && columns[i + span].groupIndex === gIdx) span++;
            const th = document.createElement("td");
            th.colSpan = span;
            if (i > 0) th.classList.add("ct-group-gap");
            const label = resolveLabel(this.settings.groupLabels[gIdx], this.dynamicLabelValues);
            th.textContent = label && label.length > 0 ? label : `Group ${gIdx + 1}`;
            topRow.appendChild(th);
            i += span;
        }
        thead.appendChild(topRow);

        const subRow = document.createElement("tr");
        columns.forEach((c, idx) => {
            const th = document.createElement("td");
            if (c.isGroupStart && idx > 0) th.classList.add("ct-group-gap");
            th.textContent = c.subLabel;
            subRow.appendChild(th);
        });
        thead.appendChild(subRow);

        return thead;
    }

    // بيضيف أيقونة الـ +/- (لو مفعّلة) والنص جوه أي خلية، ويربط حدث الضغط للـ Expand/Collapse
    private appendToggleAndLabel(cell: HTMLTableCellElement, label: string, clickable: boolean, parentKey: string) {
        if (clickable) {
            if (this.settings.showToggleIcon) {
                const icon = document.createElement("span");
                icon.className = "ct-toggle-icon";
                icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
                cell.appendChild(icon);
                (cell as any)._toggleIcon = icon;
            }
            cell.style.cursor = "pointer";
            cell.addEventListener("click", () => {
                this.expandedState[parentKey] = !this.expandedState[parentKey];
                const rows = this.target.querySelectorAll(`tr[data-parent="${CSS.escape(parentKey)}"]`);
                rows.forEach((r: HTMLElement) => {
                    r.style.display = this.expandedState[parentKey] ? "" : "none";
                });
                const icon = (cell as any)._toggleIcon as HTMLElement;
                if (icon) icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
            });
        }
        cell.appendChild(document.createTextNode(label));
    }

    private buildDataRow(label: string, values: number[], columns: IColumnInfo[], isParent: boolean, clickable: boolean, parentKey: string, rowBgColor?: string): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = isParent ? "ct-dept-row" : "ct-ce-row";

        const labelCell = document.createElement("td");
        labelCell.className = isParent ? "ct-dept-title" : "ct-ce-title";
        if (isParent) {
            this.appendToggleAndLabel(labelCell, label, clickable, parentKey);
            labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        } else {
            labelCell.textContent = label;
            if (rowBgColor) labelCell.style.backgroundColor = rowBgColor;
        }
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "ct-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("ct-group-gap");
            if (rowBgColor) cell.style.backgroundColor = rowBgColor;
            if (v < 0) cell.style.color = this.settings.negativeColor;
            if (isParent) {
                cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            } else {
                cell.style.fontWeight = this.settings.boldChildNumbers ? "bold" : "normal";
            }
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private buildTotalRow(label: string, values: number[], columns: IColumnInfo[]): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = "ct-total-row";

        const labelCell = document.createElement("td");
        labelCell.className = "ct-total-title";
        labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        labelCell.textContent = label;
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "ct-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("ct-group-gap");
            if (v < 0) cell.style.color = this.settings.negativeColor;
            cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private applyThemeVars() {
        this.target.style.setProperty("--ct-header-color", this.settings.headerColor);
        this.target.style.setProperty("--ct-group-header-color", this.settings.groupHeaderColor);
        this.target.style.setProperty("--ct-total-row-color", this.settings.totalRowColor);
        this.target.style.setProperty("--ct-gap-width", `${this.settings.groupGapWidth}px`);
    }

    private parseSettings(dataView: DataView): ISettings {
        const settings = getDefaultSettings();
        const objects = dataView && dataView.metadata && dataView.metadata.objects;
        if (!objects) return settings;

        const dp: any = objects["dataPoint"];
        const tf: any = objects["tableFormat"];
        const gl: any = objects["groupLabels"];
        const tr: any = objects["totalRows"];
        const dh: any = objects["descriptionHeader"];


        if (dp) {
            if (dp.negativeColor && dp.negativeColor.solid) settings.negativeColor = dp.negativeColor.solid.color;
            if (dp.headerColor && dp.headerColor.solid) settings.headerColor = dp.headerColor.solid.color;
            if (dp.groupHeaderColor && dp.groupHeaderColor.solid) settings.groupHeaderColor = dp.groupHeaderColor.solid.color;
            if (dp.totalRowColor && dp.totalRowColor.solid) settings.totalRowColor = dp.totalRowColor.solid.color;
        }
        if (tf) {
            if (typeof tf.fontSize === "number") settings.fontSize = tf.fontSize;
            if (typeof tf.defaultExpanded === "boolean") settings.defaultExpanded = tf.defaultExpanded;
            if (typeof tf.groupGapWidth === "number") settings.groupGapWidth = tf.groupGapWidth;
            if (typeof tf.showToggleIcon === "boolean") settings.showToggleIcon = tf.showToggleIcon;
            if (typeof tf.boldMainRows === "boolean") settings.boldMainRows = tf.boldMainRows;
            if (typeof tf.boldChildNumbers === "boolean") settings.boldChildNumbers = tf.boldChildNumbers;
        }
        if (gl) {
            settings.groupLabels = [1, 2, 3, 4, 5, 6].map(n => (typeof gl[`group${n}Label`] === "string" ? gl[`group${n}Label`] : ""));
        }
        if (tr) {
            settings.totalRows = [1, 2, 3].map(n => ({
                enabled: typeof tr[`enableRow${n}`] === "boolean" ? tr[`enableRow${n}`] : false,
                label: typeof tr[`label${n}`] === "string" && tr[`label${n}`] ? tr[`label${n}`] : "Total"
            }));
        }
        if (dh) {
            if (typeof dh.twoLines === "boolean") settings.descTwoLines = dh.twoLines;
            if (typeof dh.line1Text === "string" && dh.line1Text) settings.descLine1 = dh.line1Text;
            if (typeof dh.line2Text === "string") settings.descLine2 = dh.line2Text;
            if (typeof dh.separatorSize === "number") settings.descSeparatorSize = dh.separatorSize;
        }
        return settings;
    }

    public enumerateObjectInstances(options: powerbi.EnumerateVisualObjectInstancesOptions): powerbi.VisualObjectInstanceEnumeration {
        const objectName = options.objectName;
        const settings = this.settings || getDefaultSettings();
        const instances: powerbi.VisualObjectInstance[] = [];

        if (objectName === "dataPoint") {
            instances.push({
                objectName,
                properties: {
                    negativeColor: { solid: { color: settings.negativeColor } },
                    headerColor: { solid: { color: settings.headerColor } },
                    groupHeaderColor: { solid: { color: settings.groupHeaderColor } },
                    totalRowColor: { solid: { color: settings.totalRowColor } }
                },
                selector: null
            });
        }
        if (objectName === "tableFormat") {
            instances.push({
                objectName,
                properties: {
                    fontSize: settings.fontSize,
                    defaultExpanded: settings.defaultExpanded,
                    groupGapWidth: settings.groupGapWidth,
                    showToggleIcon: settings.showToggleIcon,
                    boldMainRows: settings.boldMainRows,
                    boldChildNumbers: settings.boldChildNumbers
                },
                selector: null
            });
        }
        if (objectName === "groupLabels") {
            const props: any = {};
            settings.groupLabels.forEach((label, idx) => { props[`group${idx + 1}Label`] = label; });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "columnLabels") {
            // صندوق نص منفصل لكل عمود (Measure) فعليًا متسحب في أي Group - تكتب فيه الاسم الجديد مباشرة
            this.columnEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withMeasure(entry.column.source.queryName)
                    .createSelectionId();
                const existingText = this.getColumnText(entry.column);
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: { newName: existingText || entry.label },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "rowColors") {
            // صف منفصل لكل Cost Element فريد، معاه Color picker جاهز - زي "Data colors" بالظبط
            this.ceCategoryEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withCategory(entry.column, entry.index)
                    .createSelectionId();
                const existingColor = this.getCategoryFillColor(entry.column, entry.index);
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: { fill: { solid: { color: existingColor || "#FFFFFF" } } },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "totalRows") {
            const props: any = {};
            settings.totalRows.forEach((tr, idx) => {
                const n = idx + 1;
                props[`enableRow${n}`] = tr.enabled;
                props[`label${n}`] = tr.label;
            });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "totalRowInclusion") {
            // صف منفصل لكل Department فعليًا موجود، معاه 3 مفاتيح تشغيل (واحد لكل صف Total)
            this.deptCategoryEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withCategory(entry.column, entry.index)
                    .createSelectionId();
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: {
                        include1: this.getInclusionFlag(entry.column, entry.index, 1),
                        include2: this.getInclusionFlag(entry.column, entry.index, 2),
                        include3: this.getInclusionFlag(entry.column, entry.index, 3)
                    },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "descriptionHeader") {
            instances.push({
                objectName,
                properties: {
                    twoLines: settings.descTwoLines,
                    line1Text: settings.descLine1,
                    line2Text: settings.descLine2,
                    separatorSize: settings.descSeparatorSize
                },
                selector: null
            });
        }
        return instances;
    }
}
