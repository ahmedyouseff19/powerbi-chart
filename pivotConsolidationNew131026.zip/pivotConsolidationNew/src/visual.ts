"use strict";

import "../style/visual.less";
import powerbi from "powerbi-visuals-api";

import IVisual = powerbi.extensibility.visual.IVisual;
import VisualConstructorOptions = powerbi.extensibility.visual.VisualConstructorOptions;
import VisualUpdateOptions = powerbi.extensibility.visual.VisualUpdateOptions;
import IVisualHost = powerbi.extensibility.visual.IVisualHost;
import DataView = powerbi.DataView;
import DataViewValueColumnGroup = powerbi.DataViewValueColumnGroup;
import DataViewValueColumn = powerbi.DataViewValueColumn;
import DataViewValueColumns = powerbi.DataViewValueColumns;
import DataViewCategoryColumn = powerbi.DataViewCategoryColumn;

const BUCKET_ROLES = ["bucket1", "bucket2", "bucket3", "bucket4", "bucket5", "bucket6"];
const TOTAL_KEY = "__TOTAL__"; // مفتاح داخلي يمثل عمود الـ Total التلقائي (مش قيمة حقيقية من الداتا)

interface ITotalRowConfig {
    enabled: boolean;
    label: string;
}

interface ISettings {
    negativeColor: string;
    headerColor: string;
    totalRowColor: string;
    fontSize: number;
    defaultExpanded: boolean;
    groupGapWidth: number;
    showToggleIcon: boolean;
    boldMainRows: boolean;
    boldChildNumbers: boolean;
    groupTotalEnabled: boolean[]; // إظهار/إخفاء عمود Total لكل Group (1-6) بشكل مستقل
    totalSubColumnLabel: string;
    showSuperTotalColumn: boolean; // إظهار عمود Total على مستوى المجموعة الكبيرة
    superTotalColumnLabel: string;
    bucketLabels: string[];
    superGroups: string[]; // اسم المجموعة الكبيرة اللي كل سلة تتبعها (فاضي = مفيش مجموعة كبيرة)

    totalRows: ITotalRowConfig[];
    descTwoLines: boolean;
    descLine1: string;
    descLine2: string;
    descSeparatorSize: number;
}

function getDefaultSettings(): ISettings {
    return {
        negativeColor: "#E20000",
        headerColor: "#E20000",
        totalRowColor: "#F0F0F0",
        fontSize: 13,
        defaultExpanded: true,
        groupGapWidth: 8,
        showToggleIcon: true,
        boldMainRows: true,
        boldChildNumbers: false,
        groupTotalEnabled: [true, true, true, true, true, true],
        totalSubColumnLabel: "Total",
        showSuperTotalColumn: true,
        superTotalColumnLabel: "Total",
        bucketLabels: ["", "", "", "", "", ""],
        superGroups: ["", "", "", "", "", ""],

        totalRows: [
            { enabled: false, label: "Total" },
            { enabled: false, label: "Total" },
            { enabled: false, label: "Total" }
        ],
        descTwoLines: false,
        descLine1: "Description",
        descLine2: "",
        descSeparatorSize: 1
    };
}

function formatNumber(value: number, decimals: number = 0): string {
    if (value === null || value === undefined || isNaN(value)) return "";
    const abs = Math.abs(value).toLocaleString("en-US", {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals
    });
    return value < 0 ? `(${abs})` : abs;
}

// وصف عمود معروض واحد: إما عمود فئة حقيقي (Below/Dep/Opex) أو عمود الـ Total التلقائي
interface IDisplayColumn {
    bucketIndex: number; // سالب = عمود Total على مستوى المجموعة الكبيرة (مش تابع لسلة واحدة)
    bucketIndices?: number[]; // للـ Total الكبير بس: كل السلال اللي بيتم تجميعها
    categoryKey: string; // TOTAL_KEY للعمود التلقائي
    label: string;
    superGroup: string; // اسم المجموعة الكبيرة فوق (فاضي = مفيش)
    isGroupStart: boolean;
    isTotalColumn: boolean;
    isSuperTotalColumn: boolean;
}

export class Visual implements IVisual {
    private target: HTMLElement;
    private settings: ISettings;
    private expandedState: { [key: string]: boolean } = {};
    private host: IVisualHost;
    // كل Row sub-level فريد (اسمه + أول عمود/صف لقيناه فيه)، بنعيد بناءها كل update() وبنستخدمها لبناء الـ Color pickers
    private subCategoryEntries: { label: string; column: DataViewCategoryColumn; index: number }[] = [];
    // كل Row (المستوى الأساسي) فريد - لبناء مفاتيح "ادخل في Total N؟" تلقائيًا
    private rowCategoryEntries: { label: string; column: DataViewCategoryColumn; index: number }[] = [];
    // كل قيمة عمود (P&L Category) فريدة - لبناء صندوق "اسم جديد" تلقائي لكل عمود فرعي
    private columnGroupEntries: { label: string; group: DataViewValueColumnGroup }[] = [];
    private lastValueColumns: DataViewValueColumns;

    constructor(options: VisualConstructorOptions) {
        this.target = options.element;
        this.host = options.host;
        this.target.classList.add("pc-visual-root");
    }

    public update(options: VisualUpdateOptions) {
        this.target.innerHTML = "";

        const dataView = options.dataViews && options.dataViews[0];
        if (!dataView || !dataView.categorical || !dataView.categorical.categories || !dataView.categorical.categories.length || !dataView.categorical.values) {
            this.target.innerHTML = `<div class="pc-empty">Add a Row field, a Column values field, and at least one field in any Group (1 to 6)</div>`;
            return;
        }

        this.settings = this.parseSettings(dataView);
        this.applyThemeVars();

        const categorical = dataView.categorical;
        const rowColumn = categorical.categories[0];
        const rowSubColumn = categorical.categories.length > 1 ? categorical.categories[1] : null;

        const rowValues: string[] = rowColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString());
        const rowSubValues: string[] | null = rowSubColumn ? rowSubColumn.values.map(v => (v === null || v === undefined) ? "" : v.toString()) : null;

        const groups: DataViewValueColumnGroup[] = categorical.values.grouped ? categorical.values.grouped() : [];
        this.lastValueColumns = categorical.values;

        // ترتيب القيم (Below, Dep, Opex...) بنفس ترتيب ظهورها الأول في الداتا
        const categoryOrder: string[] = groups.map(g => (g.name !== null && g.name !== undefined) ? g.name.toString() : "");

        // قايمة كل قيمة عمود (P&L Category) فريدة - هتستخدم لبناء صندوق "اسم جديد" تلقائي لكل عمود
        this.columnGroupEntries = groups.map((g, idx) => ({ label: categoryOrder[idx], group: g }));

        // نحدد أنهي سلال (buckets) فعليًا فيها بيانات
        const usedBuckets: number[] = [];
        BUCKET_ROLES.forEach((role, idx) => {
            const hasData = groups.some(g => g.values.some(c => c.source.roles && c.source.roles[role]));
            if (hasData) usedBuckets.push(idx);
        });

        // بناء قائمة الأعمدة المعروضة: لكل سلة مستخدمة -> كل الفئات بالترتيب -> عمود Total تلقائي (لو مفعّل)
        const displayColumns: IDisplayColumn[] = [];
        let superTotalCounter = 0; // عداد بيدينا رقم سالب فريد لكل عمود Total كبير (عشان يتعامل كـ "سلة" منفردة في صف الهيدر الأوسط)

        // نجمّع السلال المستخدمة في "كتل" حسب المجموعة الكبيرة: أي سلال متتالية بنفس اسم المجموعة الكبيرة بتتحط في كتلة واحدة
        const superKeyOf = (bucketIdx: number) => {
            const sg = this.settings.superGroups[bucketIdx] || "";
            return sg.length > 0 ? sg : `__none_${bucketIdx}`;
        };

        let bi = 0;
        while (bi < usedBuckets.length) {
            const key = superKeyOf(usedBuckets[bi]);
            let blockEnd = bi;
            while (blockEnd + 1 < usedBuckets.length && superKeyOf(usedBuckets[blockEnd + 1]) === key) blockEnd++;

            const blockBuckets = usedBuckets.slice(bi, blockEnd + 1);
            const isRealSuperGroup = (this.settings.superGroups[usedBuckets[bi]] || "").length > 0;

            blockBuckets.forEach(bucketIdx => {
                const superGroupLabel = this.settings.superGroups[bucketIdx] || "";
                categoryOrder.forEach((catName, catIdx) => {
                    const customText = this.getGroupText(groups[catIdx]);
                    displayColumns.push({
                        bucketIndex: bucketIdx,
                        categoryKey: catName,
                        label: customText || catName,
                        superGroup: superGroupLabel,
                        isGroupStart: catIdx === 0,
                        isTotalColumn: false,
                        isSuperTotalColumn: false
                    });
                });
                if (this.settings.groupTotalEnabled[bucketIdx]) {
                    displayColumns.push({
                        bucketIndex: bucketIdx,
                        categoryKey: TOTAL_KEY,
                        label: this.settings.totalSubColumnLabel,
                        superGroup: superGroupLabel,
                        isGroupStart: categoryOrder.length === 0,
                        isTotalColumn: true,
                        isSuperTotalColumn: false
                    });
                }
            });

            // بعد ما نخلص كل سلال الكتلة دي، لو دي فعلاً مجموعة كبيرة حقيقية (مش سلة منفردة)، نضيف عمود Total واحد ليها
            if (isRealSuperGroup && this.settings.showSuperTotalColumn) {
                superTotalCounter++;
                displayColumns.push({
                    bucketIndex: -superTotalCounter,
                    bucketIndices: blockBuckets,
                    categoryKey: TOTAL_KEY,
                    label: this.settings.superTotalColumnLabel,
                    superGroup: this.settings.superGroups[usedBuckets[bi]] || "",
                    isGroupStart: true,
                    isTotalColumn: true,
                    isSuperTotalColumn: true
                });
            }

            bi = blockEnd + 1;
        }

        const table = document.createElement("table");
        table.className = "pc-table";
        table.style.fontSize = `${this.settings.fontSize}px`;
        table.appendChild(this.buildTwoLevelHeader(displayColumns));

        const tbody = document.createElement("tbody");
        const rowCount = rowValues.length;
        const allIndices = Array.from({ length: rowCount }, (_, i) => i);

        const rowOrder: string[] = [];
        rowValues.forEach(r => { if (rowOrder.indexOf(r) === -1) rowOrder.push(r); });

        // قايمة كل Row (المستوى الأساسي) فريد - لبناء مفاتيح "ادخل في Total N؟" تلقائيًا
        this.rowCategoryEntries = rowOrder.map(label => ({
            label,
            column: rowColumn,
            index: rowValues.indexOf(label)
        }));

        // قايمة كل Row sub-level فريد (باسمه) مع أول صف لقيناه فيه - دي اللي هتظهر كـ Color picker منفصل
        this.subCategoryEntries = [];
        if (rowSubColumn) {
            const seenSub = new Set<string>();
            rowSubValues!.forEach((v, i) => {
                if (!seenSub.has(v)) {
                    seenSub.add(v);
                    this.subCategoryEntries.push({ label: v, column: rowSubColumn, index: i });
                }
            });
        }

        rowOrder.forEach(rowName => {
            if (this.expandedState[rowName] === undefined) {
                this.expandedState[rowName] = this.settings.defaultExpanded;
            }
            const rIndices = allIndices.filter(i => rowValues[i] === rowName);
            const hasChildren = !!rowSubValues;

            const parentValues = displayColumns.map(dc => this.computeCell(groups, dc, rIndices));
            tbody.appendChild(this.buildDataRow(rowName, parentValues, displayColumns, true, hasChildren, rowName));

            if (hasChildren) {
                const subOrder: string[] = [];
                rIndices.forEach(i => { const s = rowSubValues![i]; if (subOrder.indexOf(s) === -1) subOrder.push(s); });

                subOrder.forEach(subName => {
                    const subIndices = rIndices.filter(i => rowSubValues![i] === subName);
                    const subValues = displayColumns.map(dc => this.computeCell(groups, dc, subIndices));
                    const rowBgColor = this.getCategoryFillColor(rowSubColumn!, subIndices[0]);
                    const row = this.buildDataRow(subName, subValues, displayColumns, false, false, rowName, rowBgColor);
                    row.dataset.parent = rowName;
                    row.style.display = this.expandedState[rowName] ? "" : "none";
                    tbody.appendChild(row);
                });
            }
        });

        this.settings.totalRows.forEach((tr, idx) => {
            if (!tr.enabled) return;
            const n = idx + 1;
            // الافتراضي: كل Row مشمول، إلا لو قفلته بنفسك من مفتاح "ادخل في Total N؟"
            const matchedIndices = allIndices.filter(i => this.getInclusionFlag(rowColumn, i, n));
            const totals = displayColumns.map(dc => this.computeCell(groups, dc, matchedIndices));
            tbody.appendChild(this.buildTotalRow(tr.label, totals, displayColumns));
        });

        table.appendChild(tbody);
        this.target.appendChild(table);
    }

    // بيحسب قيمة خلية واحدة: إما مجموع فئة معينة، أو Total (مجموع كل الفئات) لنفس السلة، على مجموعة من صفوف الداتا
    private computeCell(groups: DataViewValueColumnGroup[], dc: IDisplayColumn, indices: number[]): number {
        if (dc.isSuperTotalColumn) {
            let sum = 0;
            (dc.bucketIndices || []).forEach(bIdx => {
                groups.forEach(g => {
                    const col = this.findBucketColumn(g, bIdx);
                    if (col) sum += this.sumIndices(col, indices);
                });
            });
            return sum;
        }
        if (dc.isTotalColumn) {
            let sum = 0;
            groups.forEach(g => {
                const col = this.findBucketColumn(g, dc.bucketIndex);
                if (col) sum += this.sumIndices(col, indices);
            });
            return sum;
        }
        const group = groups.find(g => ((g.name !== null && g.name !== undefined) ? g.name.toString() : "") === dc.categoryKey);
        if (!group) return 0;
        const col = this.findBucketColumn(group, dc.bucketIndex);
        if (!col) return 0;
        return this.sumIndices(col, indices);
    }

    private findBucketColumn(group: DataViewValueColumnGroup, bucketIndex: number): DataViewValueColumn | undefined {
        const role = BUCKET_ROLES[bucketIndex];
        return group.values.find(c => c.source.roles && c.source.roles[role]);
    }

    // بيقرأ اللون اللي Power BI حفظه لصف معين (لو المستخدم اختاره من الـ Color picker في الـ Format pane)
    private getCategoryFillColor(column: DataViewCategoryColumn, rowIndex: number): string | undefined {
        const objs: any = column.objects && column.objects[rowIndex];
        if (objs && objs["rowColors"] && objs["rowColors"].fill && objs["rowColors"].fill.solid) {
            return objs["rowColors"].fill.solid.color;
        }
        return undefined;
    }

    // بيقرأ الاسم الجديد اللي المستخدم كتبه لقيمة عمود معينة (P&L Category) من الـ Format pane، لو موجود
    private getGroupText(group: DataViewValueColumnGroup): string | undefined {
        const objs: any = group.objects;
        if (objs && objs["columnLabels"] && typeof objs["columnLabels"].newName === "string" && objs["columnLabels"].newName) {
            return objs["columnLabels"].newName;
        }
        return undefined;
    }

    // بيقرأ هل الصف ده (Row) مشمول في صف Total رقم n - الافتراضي true لو المستخدم معملش حاجة
    private getInclusionFlag(column: DataViewCategoryColumn, rowIndex: number, n: number): boolean {
        const objs: any = column.objects && column.objects[rowIndex];
        if (objs && objs["totalRowInclusion"] && typeof objs["totalRowInclusion"][`include${n}`] === "boolean") {
            return objs["totalRowInclusion"][`include${n}`];
        }
        return true;
    }

    private sumIndices(col: DataViewValueColumn, indices: number[]): number {
        let sum = 0;
        indices.forEach(i => {
            const v = col.values[i] as number;
            if (v !== null && v !== undefined && !isNaN(v)) sum += v;
        });
        return sum;
    }

    private buildDescriptionCell(hasSuperRow: boolean): HTMLTableCellElement {
        const descTh = document.createElement("td");
        descTh.rowSpan = hasSuperRow ? 3 : 2;
        descTh.className = "pc-desc-header";
        if (this.settings.descTwoLines) {
            descTh.appendChild(document.createTextNode(this.settings.descLine1));
            const sep = document.createElement("div");
            sep.className = "pc-desc-separator";
            sep.style.borderTopWidth = `${this.settings.descSeparatorSize}px`;
            descTh.appendChild(sep);
            descTh.appendChild(document.createTextNode(this.settings.descLine2));
        } else {
            descTh.textContent = this.settings.descLine1;
        }
        return descTh;
    }

    private buildTwoLevelHeader(columns: IDisplayColumn[]): HTMLTableSectionElement {
        const thead = document.createElement("thead");
        const hasSuperRow = columns.some(c => c.superGroup && c.superGroup.length > 0);

        // ============ صف المجموعة الكبيرة (اختياري) ============
        if (hasSuperRow) {
            const superRow = document.createElement("tr");
            superRow.appendChild(this.buildDescriptionCell(true));

            // مفتاح تجميع: لو superGroup فاضي، خليه فريد لكل سلة عشان مايندمجش غلط مع سلة تانية فاضية جنبه
            const superKey = (c: IDisplayColumn) => c.superGroup && c.superGroup.length > 0 ? c.superGroup : `__none_${c.bucketIndex}`;

            let i = 0;
            while (i < columns.length) {
                const key = superKey(columns[i]);
                let span = 1;
                while (i + span < columns.length && superKey(columns[i + span]) === key) span++;
                const th = document.createElement("td");
                th.colSpan = span;
                if (i > 0) th.classList.add("pc-group-gap");
                th.textContent = columns[i].superGroup || "";
                superRow.appendChild(th);
                i += span;
            }
            thead.appendChild(superRow);
        }

        // ============ صف اسم المجموعة (Group 1، Group 2...) ============
        const topRow = document.createElement("tr");
        if (!hasSuperRow) topRow.appendChild(this.buildDescriptionCell(false));

        let i = 0;
        while (i < columns.length) {
            const bIdx = columns[i].bucketIndex;
            let span = 1;
            while (i + span < columns.length && columns[i + span].bucketIndex === bIdx) span++;
            const th = document.createElement("td");
            th.colSpan = span;
            if (i > 0) th.classList.add("pc-group-gap");
            if (columns[i].isSuperTotalColumn) {
                th.classList.add("pc-total-col");
                th.textContent = columns[i].label;
            } else {
                const label = this.settings.bucketLabels[bIdx];
                th.textContent = label && label.length > 0 ? label : `Group ${bIdx + 1}`;
            }
            topRow.appendChild(th);
            i += span;
        }
        thead.appendChild(topRow);

        // ============ صف الأعمدة الفرعية (Below, Dep, Opex, Total...) ============
        const subRow = document.createElement("tr");
        columns.forEach((c, idx) => {
            const th = document.createElement("td");
            if (c.isGroupStart && idx > 0) th.classList.add("pc-group-gap");
            if (c.isTotalColumn) th.classList.add("pc-total-col");
            th.textContent = c.label;
            subRow.appendChild(th);
        });
        thead.appendChild(subRow);

        return thead;
    }

    private appendToggleAndLabel(cell: HTMLTableCellElement, label: string, clickable: boolean, parentKey: string) {
        if (clickable) {
            if (this.settings.showToggleIcon) {
                const icon = document.createElement("span");
                icon.className = "pc-toggle-icon";
                icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
                cell.appendChild(icon);
                (cell as any)._toggleIcon = icon;
            }
            cell.style.cursor = "pointer";
            cell.addEventListener("click", () => {
                this.expandedState[parentKey] = !this.expandedState[parentKey];
                const rows = this.target.querySelectorAll(`tr[data-parent="${CSS.escape(parentKey)}"]`);
                rows.forEach((r: HTMLElement) => { r.style.display = this.expandedState[parentKey] ? "" : "none"; });
                const icon = (cell as any)._toggleIcon as HTMLElement;
                if (icon) icon.textContent = this.expandedState[parentKey] ? "－ " : "＋ ";
            });
        }
        cell.appendChild(document.createTextNode(label));
    }

    private buildDataRow(label: string, values: number[], columns: IDisplayColumn[], isParent: boolean, clickable: boolean, parentKey: string, rowBgColor?: string): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = isParent ? "pc-main-row" : "pc-sub-row";

        const labelCell = document.createElement("td");
        labelCell.className = isParent ? "pc-main-title" : "pc-sub-title";
        if (isParent) {
            this.appendToggleAndLabel(labelCell, label, clickable, parentKey);
            labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        } else {
            labelCell.textContent = label;
            if (rowBgColor) labelCell.style.backgroundColor = rowBgColor;
        }
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "pc-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("pc-group-gap");
            if (columns[idx].isTotalColumn) cell.classList.add("pc-total-col");
            if (rowBgColor) cell.style.backgroundColor = rowBgColor;
            if (v < 0) cell.style.color = this.settings.negativeColor;
            if (isParent) {
                cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            } else {
                cell.style.fontWeight = this.settings.boldChildNumbers ? "bold" : "normal";
            }
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private buildTotalRow(label: string, values: number[], columns: IDisplayColumn[]): HTMLTableRowElement {
        const row = document.createElement("tr");
        row.className = "pc-grand-total-row";

        const labelCell = document.createElement("td");
        labelCell.className = "pc-grand-total-title";
        labelCell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
        labelCell.textContent = label;
        row.appendChild(labelCell);

        values.forEach((v, idx) => {
            const cell = document.createElement("td");
            cell.className = "pc-value-cell";
            if (columns[idx].isGroupStart && idx > 0) cell.classList.add("pc-group-gap");
            if (columns[idx].isTotalColumn) cell.classList.add("pc-total-col");
            if (v < 0) cell.style.color = this.settings.negativeColor;
            cell.style.fontWeight = this.settings.boldMainRows ? "bold" : "normal";
            cell.textContent = formatNumber(v, 0);
            row.appendChild(cell);
        });

        return row;
    }

    private applyThemeVars() {
        this.target.style.setProperty("--pc-header-color", this.settings.headerColor);
        this.target.style.setProperty("--pc-total-row-color", this.settings.totalRowColor);
        this.target.style.setProperty("--pc-gap-width", `${this.settings.groupGapWidth}px`);
    }

    private parseSettings(dataView: DataView): ISettings {
        const settings = getDefaultSettings();
        const objects = dataView && dataView.metadata && dataView.metadata.objects;
        if (!objects) return settings;

        const dp: any = objects["dataPoint"];
        const tf: any = objects["tableFormat"];
        const bl: any = objects["bucketLabels"];
        const sg: any = objects["superGroups"];
        const gt: any = objects["groupTotals"];
        const tr: any = objects["totalRows"];
        const dh: any = objects["descriptionHeader"];


        if (dp) {
            if (dp.negativeColor && dp.negativeColor.solid) settings.negativeColor = dp.negativeColor.solid.color;
            if (dp.headerColor && dp.headerColor.solid) settings.headerColor = dp.headerColor.solid.color;
            if (dp.totalRowColor && dp.totalRowColor.solid) settings.totalRowColor = dp.totalRowColor.solid.color;
        }
        if (tf) {
            if (typeof tf.fontSize === "number") settings.fontSize = tf.fontSize;
            if (typeof tf.defaultExpanded === "boolean") settings.defaultExpanded = tf.defaultExpanded;
            if (typeof tf.groupGapWidth === "number") settings.groupGapWidth = tf.groupGapWidth;
            if (typeof tf.showToggleIcon === "boolean") settings.showToggleIcon = tf.showToggleIcon;
            if (typeof tf.boldMainRows === "boolean") settings.boldMainRows = tf.boldMainRows;
            if (typeof tf.boldChildNumbers === "boolean") settings.boldChildNumbers = tf.boldChildNumbers;
            if (typeof tf.totalSubColumnLabel === "string" && tf.totalSubColumnLabel) settings.totalSubColumnLabel = tf.totalSubColumnLabel;
            if (typeof tf.showSuperTotalColumn === "boolean") settings.showSuperTotalColumn = tf.showSuperTotalColumn;
            if (typeof tf.superTotalColumnLabel === "string" && tf.superTotalColumnLabel) settings.superTotalColumnLabel = tf.superTotalColumnLabel;
        }
        if (gt) {
            settings.groupTotalEnabled = [1, 2, 3, 4, 5, 6].map(n => (typeof gt[`bucket${n}ShowTotal`] === "boolean" ? gt[`bucket${n}ShowTotal`] : true));
        }
        if (bl) {
            settings.bucketLabels = [1, 2, 3, 4, 5, 6].map(n => (typeof bl[`bucket${n}Label`] === "string" ? bl[`bucket${n}Label`] : ""));
        }
        if (sg) {
            settings.superGroups = [1, 2, 3, 4, 5, 6].map(n => (typeof sg[`bucket${n}Super`] === "string" ? sg[`bucket${n}Super`] : ""));
        }
        if (tr) {
            settings.totalRows = [1, 2, 3].map(n => ({
                enabled: typeof tr[`enableRow${n}`] === "boolean" ? tr[`enableRow${n}`] : false,
                label: typeof tr[`label${n}`] === "string" && tr[`label${n}`] ? tr[`label${n}`] : "Total"
            }));
        }
        if (dh) {
            if (typeof dh.twoLines === "boolean") settings.descTwoLines = dh.twoLines;
            if (typeof dh.line1Text === "string" && dh.line1Text) settings.descLine1 = dh.line1Text;
            if (typeof dh.line2Text === "string") settings.descLine2 = dh.line2Text;
            if (typeof dh.separatorSize === "number") settings.descSeparatorSize = dh.separatorSize;
        }
        return settings;
    }

    public enumerateObjectInstances(options: powerbi.EnumerateVisualObjectInstancesOptions): powerbi.VisualObjectInstanceEnumeration {
        const objectName = options.objectName;
        const settings = this.settings || getDefaultSettings();
        const instances: powerbi.VisualObjectInstance[] = [];

        if (objectName === "dataPoint") {
            instances.push({
                objectName,
                properties: {
                    negativeColor: { solid: { color: settings.negativeColor } },
                    headerColor: { solid: { color: settings.headerColor } },
                    totalRowColor: { solid: { color: settings.totalRowColor } }
                },
                selector: null
            });
        }
        if (objectName === "tableFormat") {
            instances.push({
                objectName,
                properties: {
                    fontSize: settings.fontSize,
                    defaultExpanded: settings.defaultExpanded,
                    groupGapWidth: settings.groupGapWidth,
                    showToggleIcon: settings.showToggleIcon,
                    boldMainRows: settings.boldMainRows,
                    boldChildNumbers: settings.boldChildNumbers,
                    totalSubColumnLabel: settings.totalSubColumnLabel,
                    showSuperTotalColumn: settings.showSuperTotalColumn,
                    superTotalColumnLabel: settings.superTotalColumnLabel
                },
                selector: null
            });
        }
        if (objectName === "groupTotals") {
            const props: any = {};
            settings.groupTotalEnabled.forEach((enabled, idx) => { props[`bucket${idx + 1}ShowTotal`] = enabled; });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "bucketLabels") {
            const props: any = {};
            settings.bucketLabels.forEach((label, idx) => { props[`bucket${idx + 1}Label`] = label; });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "superGroups") {
            const props: any = {};
            settings.superGroups.forEach((label, idx) => { props[`bucket${idx + 1}Super`] = label; });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "columnLabels") {
            // صندوق نص منفصل لكل قيمة عمود (P&L Category) فعليًا موجودة في الداتا - تكتب فيه الاسم الجديد مباشرة
            this.columnGroupEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withSeries(this.lastValueColumns, entry.group)
                    .createSelectionId();
                const existingText = this.getGroupText(entry.group);
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: { newName: existingText || entry.label },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "rowColors") {
            // صف منفصل لكل Row sub-level فريد، معاه Color picker جاهز - زي "Data colors" بالظبط
            this.subCategoryEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withCategory(entry.column, entry.index)
                    .createSelectionId();
                const existingColor = this.getCategoryFillColor(entry.column, entry.index);
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: { fill: { solid: { color: existingColor || "#FFFFFF" } } },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "totalRows") {
            const props: any = {};
            settings.totalRows.forEach((tr, idx) => {
                const n = idx + 1;
                props[`enableRow${n}`] = tr.enabled;
                props[`label${n}`] = tr.label;
            });
            instances.push({ objectName, properties: props, selector: null });
        }
        if (objectName === "totalRowInclusion") {
            // صف منفصل لكل Row فعليًا موجود، معاه 3 مفاتيح تشغيل (واحد لكل صف Total)
            this.rowCategoryEntries.forEach(entry => {
                const selectionId = this.host.createSelectionIdBuilder()
                    .withCategory(entry.column, entry.index)
                    .createSelectionId();
                instances.push({
                    objectName,
                    displayName: entry.label,
                    properties: {
                        include1: this.getInclusionFlag(entry.column, entry.index, 1),
                        include2: this.getInclusionFlag(entry.column, entry.index, 2),
                        include3: this.getInclusionFlag(entry.column, entry.index, 3)
                    },
                    selector: selectionId.getSelector()
                });
            });
        }
        if (objectName === "descriptionHeader") {
            instances.push({
                objectName,
                properties: {
                    twoLines: settings.descTwoLines,
                    line1Text: settings.descLine1,
                    line2Text: settings.descLine2,
                    separatorSize: settings.descSeparatorSize
                },
                selector: null
            });
        }
        return instances;
    }
}
